export interface SalesProduct {
    slno: number,
    code: string,
    name: string,
    price: number,
    qty: number,
    total: number
}